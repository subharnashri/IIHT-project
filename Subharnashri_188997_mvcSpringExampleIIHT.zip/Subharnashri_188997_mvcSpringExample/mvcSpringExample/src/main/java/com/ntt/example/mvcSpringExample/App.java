package com.ntt.example.mvcSpringExample;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class App 
{
	@RequestMapping("/getPoint")
    public static ModelAndView helloWorld(ModelAndView mv)
    {
    	Point p= new Point();
    	p.setX(24.4);
    	p.setY(46.7);
    	mv.addObject("pointX", p.getX());
    	mv.addObject("pointY", p.getY());
    	mv.setViewName("helloWorld");
		return mv;
       
    }
}
