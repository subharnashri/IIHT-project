import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class MyForm extends React.Component {
  render() {
    const mystyle = {
      color: "black",
      backgroundColor: "DodgerBlue",
      padding: "10px",
      fontFamily: "times new roman"
    };
    return (
      <form>
        <center><h1 style={mystyle}>WELCOME </h1></center>
         <p>FIRST NAME:</p>
      <input
        type='text'
        name='userid'
        />
      <p>SECOND NAME:</p>
      <input
        type='text'
        name='username'
       
      />
       
       <p>EMAIL-ID:</p>
      <input
        type='text'
        name='usermail'
        
      />
      <p>PASSWORD:</p>
      <input
        type='password'
        name='userpass'
        
      />
      <p>LOCATION:</p>
      <input
        type='text'
        name='userlocation'
        
      />
       <br/>
      <br/>
      <input type='submit' />
      
      </form>
    );
  }
}
ReactDOM.render(<MyForm />, document.getElementById('root'));
